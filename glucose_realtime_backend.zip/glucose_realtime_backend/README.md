# Glucose Realtime Backend (FastAPI)

Bu backend 3 işi aynı anda yapar:
1) Cihazdan / simülatörden gelen **anlık voltaj/glikoz** verisini alır (HTTP POST veya WebSocket)
2) Bağlı mobil istemcilere **canlı akış** gönderir (WebSocket)
3) Son verilerden **AI prediction** (trend tabanlı kısa-vadeli tahmin) üretir (REST + WS)

## 1) Kurulum (Mac)
```bash
cd glucose_realtime_backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## 2) URL'ler
- Health: `GET /health`
- Veri gönder: `POST /api/v1/readings`
- Veri liste: `GET /api/v1/readings?limit=100`
- Tahmin: `GET /api/v1/predict?horizon_seconds=300&step_seconds=10`
- Canlı akış: `WS /ws/stream`
- Canlı tahmin: `WS /ws/predictions`

## 3) Örnek veri gönderme (curl)
```bash
curl -X POST "http://localhost:8000/api/v1/readings" \
  -H "Content-Type: application/json" \
  -d '{"voltage": 1.799, "timestamp": "2025-12-30T12:00:00Z"}'
```

## 4) Cihaz tarafı entegrasyon mantığı
Cihaz kodun her ölçümde backend'e şunu yollasın:
- `voltage` (zorunlu)
- `timestamp` (opsiyonel; yoksa backend server zamanı kullanır)
- `glucose` (opsiyonel; yoksa backend kalibrasyonla hesaplar)

> Not: Kalibrasyon parametreleri `app/config.py` içinde.

## 5) Flutter tarafı (özet)
- Gerçek zamanlı değerler için `web_socket_channel` ile `ws://<IP>:8000/ws/stream`
- Tahmin için `ws://<IP>:8000/ws/predictions` veya REST `GET /api/v1/predict`

Android Emulator kullanıyorsan host için genelde:
- `http://10.0.2.2:8000`
- `ws://10.0.2.2:8000/ws/stream`

Gerçek telefonda:
- bilgisayarının LAN IP’si: `http://192.168.x.x:8000`
