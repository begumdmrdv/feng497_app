import asyncio, json
import websockets

URI="ws://localhost:8000/ws/stream"

async def main():
    async with websockets.connect(URI) as ws:
        while True:
            msg = await ws.recv()
            print(msg)

asyncio.run(main())
