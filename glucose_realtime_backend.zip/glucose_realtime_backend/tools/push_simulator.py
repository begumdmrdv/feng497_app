import time, random, requests
from datetime import datetime, timezone

BASE = "http://localhost:8000"

voltage_min=1.2
voltage_max=2.8

while True:
    v = voltage_min + random.random()*(voltage_max-voltage_min)
    payload = {"voltage": round(v, 3), "timestamp": datetime.now(timezone.utc).isoformat()}
    r = requests.post(f"{BASE}/api/v1/readings", json=payload, timeout=5)
    print(r.status_code, r.json())
    time.sleep(1)
