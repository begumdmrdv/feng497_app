from pydantic import BaseModel

class Calibration(BaseModel):
    voltage_min: float = 1.200
    voltage_max: float = 2.800
    slope: float = 80.0
    offset: float = -40.0

CALIBRATION = Calibration()

# How many readings to keep in memory (and to serve to clients)
MAX_BUFFER = 1000
