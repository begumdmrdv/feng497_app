from __future__ import annotations
from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Optional, List

class ReadingIn(BaseModel):
    voltage: float
    glucose: Optional[float] = None
    timestamp: Optional[datetime] = None

class Reading(BaseModel):
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    voltage: float
    glucose: float
    status: str

class PredictPoint(BaseModel):
    timestamp: datetime
    predicted_glucose: float

class PredictionResponse(BaseModel):
    model: str
    points: List[PredictPoint]
    last_glucose: float
