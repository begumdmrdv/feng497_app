from __future__ import annotations
from collections import deque
from typing import Deque, List
from .models import Reading
from .config import MAX_BUFFER

class InMemoryStore:
    def __init__(self) -> None:
        self._buf: Deque[Reading] = deque(maxlen=MAX_BUFFER)

    def add(self, r: Reading) -> None:
        self._buf.append(r)

    def list(self, limit: int = 100) -> List[Reading]:
        if limit <= 0:
            return []
        # return newest last (chronological)
        data = list(self._buf)
        return data[-limit:]

    def all(self) -> List[Reading]:
        return list(self._buf)

store = InMemoryStore()
