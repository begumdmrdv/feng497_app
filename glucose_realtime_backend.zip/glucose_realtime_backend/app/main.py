from __future__ import annotations

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timezone
from typing import List

from .config import CALIBRATION
from .models import ReadingIn, Reading, PredictionResponse
from .store import store
from .realtime import broadcaster
from .predict import trend_forecast

app = FastAPI(title="Glucose Realtime Backend", version="1.0.0")

# CORS: Flutter web / mobile debug için açık
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def glucose_status(glucose: float) -> str:
    if glucose < 70:
        return "LOW"
    if glucose > 180:
        return "HIGH"
    return "NORMAL"

def compute_glucose(voltage: float) -> float:
    return (voltage * CALIBRATION.slope) + CALIBRATION.offset

@app.get("/health")
def health():
    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}

@app.post("/api/v1/readings", response_model=Reading)
async def post_reading(payload: ReadingIn):
    ts = payload.timestamp or datetime.now(timezone.utc)
    g = payload.glucose if payload.glucose is not None else compute_glucose(payload.voltage)
    r = Reading(timestamp=ts, voltage=payload.voltage, glucose=g, status=glucose_status(g))
    store.add(r)
    await broadcaster.publish({"type": "reading", "data": r.model_dump()})
    return r

@app.get("/api/v1/readings", response_model=List[Reading])
def get_readings(limit: int = 100):
    return store.list(limit=limit)

@app.get("/api/v1/predict", response_model=PredictionResponse)
def get_predict(horizon_seconds: int = 300, step_seconds: int = 10):
    readings = store.all()
    pts = trend_forecast(readings, horizon_seconds=horizon_seconds, step_seconds=step_seconds)
    last = readings[-1].glucose if readings else 0.0
    return PredictionResponse(model="linear_trend_lstsq", points=pts, last_glucose=last)

@app.websocket("/ws/stream")
async def ws_stream(ws: WebSocket):
    await ws.accept()
    q = broadcaster.register()
    try:
        # bağlantı açılınca son 50 veriyi gönder
        for r in store.list(limit=50):
            await ws.send_json({"type": "reading", "data": r.model_dump()})
        while True:
            msg = await q.get()
            await ws.send_json(msg)
    except WebSocketDisconnect:
        pass
    finally:
        broadcaster.unregister(q)

@app.websocket("/ws/predictions")
async def ws_predictions(ws: WebSocket):
    await ws.accept()
    q = broadcaster.register()
    try:
        # İlk tahmini gönder
        readings = store.all()
        pts = trend_forecast(readings, horizon_seconds=300, step_seconds=10)
        await ws.send_json({"type": "prediction", "data": {"model": "linear_trend_lstsq", "points": [p.model_dump() for p in pts]}})
        while True:
            msg = await q.get()
            if msg.get("type") == "reading":
                readings = store.all()
                pts = trend_forecast(readings, horizon_seconds=300, step_seconds=10)
                await ws.send_json({"type": "prediction", "data": {"model": "linear_trend_lstsq", "points": [p.model_dump() for p in pts]}})
    except WebSocketDisconnect:
        pass
    finally:
        broadcaster.unregister(q)
