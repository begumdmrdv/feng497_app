from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import List, Tuple
import numpy as np
from .models import Reading, PredictPoint

def _to_unix(t: datetime) -> float:
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    return t.timestamp()

def trend_forecast(readings: List[Reading], horizon_seconds: int = 300, step_seconds: int = 10) -> List[PredictPoint]:
    """
    Basit ama işe yarar kısa-vade tahmin:
    - Son N noktada zamana karşı lineer trend (least squares)
    - Gürültü azaltmak için son 5 nokta moving average uygulanır
    """
    if not readings:
        return []
    # Use last up to 60 points (1 dk örnekleme ile 1 saat)
    rs = readings[-60:]
    times = np.array([_to_unix(r.timestamp) for r in rs], dtype=float)
    values = np.array([r.glucose for r in rs], dtype=float)

    # moving average (window=5) at the tail
    if len(values) >= 5:
        kernel = np.ones(5) / 5.0
        values_smooth = np.convolve(values, kernel, mode="same")
    else:
        values_smooth = values

    # Fit y = a*t + b
    t0 = times[0]
    x = times - t0
    A = np.vstack([x, np.ones_like(x)]).T
    a, b = np.linalg.lstsq(A, values_smooth, rcond=None)[0]

    last_t = times[-1]
    start = datetime.fromtimestamp(last_t, tz=timezone.utc)
    pts: List[PredictPoint] = []
    for s in range(step_seconds, horizon_seconds + 1, step_seconds):
        ts = start + timedelta(seconds=s)
        xq = (last_t + s) - t0
        yq = float(a * xq + b)
        pts.append(PredictPoint(timestamp=ts, predicted_glucose=yq))
    return pts
