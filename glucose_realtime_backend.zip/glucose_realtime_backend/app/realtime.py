from __future__ import annotations
import asyncio
from typing import Set, Any

class Broadcaster:
    def __init__(self) -> None:
        self._clients: Set[asyncio.Queue] = set()

    def register(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=100)
        self._clients.add(q)
        return q

    def unregister(self, q: asyncio.Queue) -> None:
        self._clients.discard(q)

    async def publish(self, msg: Any) -> None:
        dead = []
        for q in list(self._clients):
            try:
                q.put_nowait(msg)
            except asyncio.QueueFull:
                # client too slow
                dead.append(q)
        for q in dead:
            self.unregister(q)

broadcaster = Broadcaster()
