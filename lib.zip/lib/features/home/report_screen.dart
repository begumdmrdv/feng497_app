import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'glucose_store.dart';
import 'report_pdf.dart';
import 'report_preview_screen.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  // AGP default: 14 days
  int _days = 14;

  bool _loading = true;
  List<GlucoseSample> _all = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _all = await GlucoseStore.getAll();
    if (mounted) setState(() => _loading = false);
  }

  // ✅ Use UTC consistently because store saves timestamps in UTC
  DateTime get _end => DateTime.now().toUtc();
  DateTime get _start => DateTime.now().toUtc().subtract(Duration(days: _days));

  // ✅ Inclusive range: [start, end]
  List<GlucoseSample> get _rangeSamples {
    final s = _start;
    final e = _end;
    return _all.where((x) {
      final ts = x.ts.toUtc();
      return !ts.isBefore(s) && !ts.isAfter(e);
    }).toList()
      ..sort((a, b) => a.ts.compareTo(b.ts));
  }

  // ---------- Metrics ----------
  double _mean(List<double> v) => v.isEmpty ? 0 : v.reduce((a, b) => a + b) / v.length;

  double _sd(List<double> v, double mean) {
    if (v.length < 2) return 0;
    final sumSq = v.map((x) => pow(x - mean, 2)).reduce((a, b) => a + b);
    return sqrt(sumSq / (v.length - 1));
  }

  // GMI (%) = 3.31 + 0.02392 * mean(mg/dL)
  double _gmi(double meanMgdl) => 3.31 + 0.02392 * meanMgdl;

  ({double tir, double tbr, double tar}) _tir(List<double> v) {
    if (v.isEmpty) return (tir: 0, tbr: 0, tar: 0);
    final inRange = v.where((x) => x >= 70 && x <= 180).length;
    final below = v.where((x) => x < 70).length;
    final above = v.where((x) => x > 180).length;
    final n = v.length.toDouble();
    return (
    tir: (inRange / n) * 100,
    tbr: (below / n) * 100,
    tar: (above / n) * 100,
    );
  }

  // ✅ NEW: Build AI insights text (simple, on-device heuristic)
  String _aiNoteFor(ReportNumbers n) {
    if (n.mean <= 0) return "AI Insight: Not enough valid data to generate insight.";
    if (n.tbr >= 4.0) {
      return "AI Insight: Increased low-glucose exposure detected (TBR elevated). Consider safer meal/activity timing and closer monitoring.";
    }
    if (n.tar >= 30.0) {
      return "AI Insight: High-glucose exposure is elevated (TAR high). Focus on carb distribution and post-meal consistency.";
    }
    if (n.tir >= 70.0) {
      return "AI Insight: Time-in-Range is strong. Maintain consistency and reduce variability.";
    }
    return "AI Insight: Mixed control. Aim to increase TIR by reducing variability and avoiding large spikes.";
  }

  String _qualityNote(int sampleCount) {
    if (sampleCount < 24) {
      return "Data Quality: Very few samples in this period. Trends may be unreliable.";
    }
    if (sampleCount < 96) {
      return "Data Quality: Moderate number of samples. Interpret trends with caution.";
    }
    return "Data Quality: Enough samples for a stable summary (sample-based).";
  }

  // ✅ NEW: Source breakdown for AI vs Live etc.
  ({int live, int ai, int manual, int unknown}) _countSources(List<GlucoseSample> samples) {
    int live = 0, ai = 0, manual = 0, unknown = 0;
    for (final s in samples) {
      switch (s.source) {
        case GlucoseSource.live:
          live++;
          break;
        case GlucoseSource.ai:
          ai++;
          break;
        case GlucoseSource.manual:
          manual++;
          break;
        default:
          unknown++;
      }
    }
    return (live: live, ai: ai, manual: manual, unknown: unknown);
  }

  Future<void> _openPdf() async {
    final samples = _rangeSamples;
    final series = samples.map((e) => e.mgdl).toList();

    if (series.length < 5) {
      _toast("Not enough glucose data in this range. (Need at least a few samples.)");
      return;
    }

    final mean = _mean(series);
    final sd = _sd(series, mean);
    final cv = mean == 0 ? 0.0 : (sd / mean) * 100.0;
    final gmi = _gmi(mean);
    final t = _tir(series);

    final numbers = ReportNumbers(
      start: _start,
      end: _end,
      mean: mean,
      sd: sd,
      cv: cv,
      gmi: gmi,
      tir: t.tir,
      tbr: t.tbr,
      tar: t.tar,
    );

    // ✅ NEW: AI insights + source breakdown passed into PDF
    final c = _countSources(samples);
    final aiInsights = ReportAiInsights(
      totalSamples: samples.length,
      liveSamples: c.live,
      aiSamples: c.ai,
      manualSamples: c.manual,
      unknownSamples: c.unknown,
      aiNote: _aiNoteFor(numbers),
      qualityNote: _qualityNote(samples.length),
    );

    final df = DateFormat("yyyy-MM-dd");
    final fileName = "DermaGly_Report_${df.format(_start)}_${df.format(_end)}.pdf";

    final Future<Uint8List> pdfFuture = ReportPdfBuilder.build(
      n: numbers,
      series: series,
      ai: aiInsights, // ✅ NEW
    );

    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ReportPreviewScreen(
          pdfFuture: pdfFuture,
          fileName: fileName,
        ),
      ),
    );
  }

  Future<void> _seedDemoData() async {
    await GlucoseStore.clearAll();
    final now = DateTime.now().toUtc();
    final rng = Random(42);

    // ✅ Mark demo data as AI (so your PDF shows AI samples even without backend)
    for (int i = 0; i < 14 * 24; i++) {
      final ts = now.subtract(Duration(minutes: 60 * i));
      final base = 110 + 35 * sin(i / 6);
      final noise = rng.nextDouble() * 18 - 9;
      final val = (base + noise).clamp(55, 260).toDouble();

      await GlucoseStore.addSample(
        mgdl: val,
        ts: ts,
        source: GlucoseSource.ai, // ✅ NEW
      );
    }
    await _load();
    _toast("Demo glucose data generated ✅ (tagged as AI samples)");
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF7B3FF2);

    final dfTop = DateFormat("d MMM yyyy");
    final rangeLabel = "${dfTop.format(_start.toLocal())}  →  ${dfTop.format(_end.toLocal())}";

    final samples = _rangeSamples;
    final series = samples.map((e) => e.mgdl).toList();
    final mean = _mean(series);
    final sd = _sd(series, mean);
    final cv = mean == 0 ? 0.0 : (sd / mean) * 100.0;
    final gmi = series.isEmpty ? 0 : _gmi(mean);
    final t = _tir(series);

    // ✅ NEW: source counts for UI display (optional but makes AI visible)
    final src = _countSources(samples);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F1E8),
      appBar: AppBar(
        backgroundColor: primary,
        elevation: 0,
        title: const Text("AGP Report"),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Range card
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  blurRadius: 18,
                  offset: const Offset(0, 10),
                  color: Colors.black.withValues(alpha: 0.06),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Report Range",
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        rangeLabel,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.black54,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "${samples.length} samples • Live ${src.live} • AI ${src.ai} • Manual ${src.manual}",
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.black38,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    value: _days,
                    borderRadius: BorderRadius.circular(14),
                    items: const [
                      DropdownMenuItem(value: 7, child: Text("7 days")),
                      DropdownMenuItem(value: 14, child: Text("14 days")),
                      DropdownMenuItem(value: 30, child: Text("30 days")),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      setState(() => _days = v);
                    },
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 14),

          // KPI cards (2x2)
          Row(
            children: [
              Expanded(
                child: _KpiCard(
                  title: "Average Glucose",
                  value: series.isEmpty ? "—" : mean.toStringAsFixed(1),
                  unit: "mg/dL",
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _KpiCard(
                  title: "GMI",
                  value: series.isEmpty ? "—" : gmi.toStringAsFixed(1),
                  unit: "%",
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _KpiCard(
                  title: "SD",
                  value: series.isEmpty ? "—" : sd.toStringAsFixed(1),
                  unit: "mg/dL",
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _KpiCard(
                  title: "CV",
                  value: series.isEmpty ? "—" : cv.toStringAsFixed(1),
                  unit: "%",
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // TIR card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  blurRadius: 18,
                  offset: const Offset(0, 10),
                  color: Colors.black.withValues(alpha: 0.06),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Time in Range (sample-based)",
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 12),
                _PctBar(label: "TIR 70–180", pct: t.tir, color: Colors.green),
                const SizedBox(height: 10),
                _PctBar(label: "TBR <70", pct: t.tbr, color: Colors.orange),
                const SizedBox(height: 10),
                _PctBar(label: "TAR >180", pct: t.tar, color: Colors.red),
                const SizedBox(height: 10),
                const Text(
                  "AGP is a standardized CGM summary. GMI is derived from mean glucose.",
                  style: TextStyle(
                    color: Colors.black45,
                    fontWeight: FontWeight.w600,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Preview button
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: _openPdf,
              icon: const Icon(Icons.picture_as_pdf_rounded),
              label: const Text(
                "Preview PDF",
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: primary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Utility row
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _load,
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text("Refresh"),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton(
                  onPressed: _seedDemoData,
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text("Generate Demo Data"),
                ),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: null,
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String title;
  final String value;
  final String unit;

  const _KpiCard({
    required this.title,
    required this.value,
    required this.unit,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            blurRadius: 18,
            offset: const Offset(0, 10),
            color: Colors.black.withValues(alpha: 0.06),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.black54),
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                value,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(width: 6),
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(
                  unit,
                  style: const TextStyle(color: Colors.black45, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PctBar extends StatelessWidget {
  final String label;
  final double pct;
  final Color color;

  const _PctBar({required this.label, required this.pct, required this.color});

  @override
  Widget build(BuildContext context) {
    final p = pct.clamp(0, 100);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))),
            Text(
              "${p.toStringAsFixed(1)}%",
              style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            value: p / 100,
            minHeight: 10,
            backgroundColor: Colors.black12,
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ],
    );
  }
}
