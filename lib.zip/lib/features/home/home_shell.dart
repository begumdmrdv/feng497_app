import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'dashboard_screen.dart';
import 'diary_screen.dart';
import 'activity_screen.dart';
import 'report_screen.dart';
import 'profile_screen.dart';

import 'glucose_store.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  WebSocketChannel? _channel;

  // ✅ Backend'den gelen EN SON glucose
  double? _liveGlucose;

  // (İstersen chart için seri de tutalım)
  final List<double> _liveSeries = [];

  @override
  void initState() {
    super.initState();
    _pruneGlucoseSamples();
    _connectWs();
  }

  void _connectWs() {
    _channel = WebSocketChannel.connect(
      Uri.parse('ws://10.0.2.2:8000/ws/stream'),
    );

    _channel!.stream.listen(
          (event) {
        final decoded = jsonDecode(event);

        if (decoded is Map && decoded['type'] == 'reading') {
          final g = (decoded['data']['glucose'] as num).toDouble();

          setState(() {
            _liveGlucose = g;

            // ✅ graph için seri (opsiyonel ama dashboard bozmaz)
            _liveSeries.add(g);
            if (_liveSeries.length > 60) {
              _liveSeries.removeAt(0);
            }
          });
        }
      },
      onError: (e) {
        // ignore: avoid_print
        print("WS error: $e");
      },
      onDone: () {
        // ignore: avoid_print
        print("WS closed");
      },
    );
  }

  Future<void> _pruneGlucoseSamples() async {
    try {
      await GlucoseStore.prune(days: 30);
    } catch (_) {}
  }

  @override
  void dispose() {
    _channel?.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      // ✅ ÖNEMLİ: Dashboard'ın gerçek parametre adları
      DashboardScreen(
        liveCurrentValue: _liveGlucose,
        liveSeries: _liveSeries,
      ),

      const DiaryScreen(),
      const ActivityScreen(),
      const ReportScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF6C2BD9),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book_rounded), label: "Diary"),
          BottomNavigationBarItem(icon: Icon(Icons.directions_run_rounded), label: "Activity"),
          BottomNavigationBarItem(icon: Icon(Icons.insert_chart_rounded), label: "Report"),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "Profile"),
        ],
      ),
    );
  }
}
